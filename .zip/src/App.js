import Header from "./Header/Header";
import Body from "./Body/Body";
import Footer from "./Footer/Footer";
import Home from "./Header/Home";
import Aboutus from "./Header/Aboutus";
import Contact from "./Header/Contact";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
	return (
		<div className="App">
			<Header />
			<BrowserRouter>
				<Routes>
					<Route path="/" element={<Body/>}/>
					<Route path="/home" element={<Home/>}/>
					<Route path="/aboutus" element={<Aboutus/>}/>
					<Route path="/contact" element={<Contact/>}/>
					
				</Routes>
			</BrowserRouter>
			<Footer />
		</div>
	);
}

export default App;
