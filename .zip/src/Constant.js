export const Cardimg = "https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/";

export const restrauntList = [
	{
		info: {
			id: "688719",
			name: "Chinese Wok",
			cloudinaryImageId: "e0839ff574213e6f35b3899ebf1fc597",
			locality: "Rahatan",
			areaName: "Pimple Saudagar",
			costForTwo: "₹250 for two",
			cuisines: ["Chinese", "Asian", "Tibetan", "Desserts"],
			avgRating: 3.9,
			parentId: "61955",
			avgRatingString: "3.9",
			totalRatingsString: "1K+",
			sla: {
				deliveryTime: 31,
				lastMileTravel: 9.3,
				serviceability: "SERVICEABLE",
				slaString: "30-35 mins",
				lastMileTravelString: "9.3 km",
				iconType: "ICON_TYPE_EMPTY",
			},
			availability: {
				nextCloseTime: "2024-05-26 02:00:00",
				opened: true,
			},
			badges: {},
			isOpen: true,
			type: "F",
			badgesV2: {
				entityBadges: {
					imageBased: {},
					textBased: {},
					textExtendedBadges: {},
				},
			},
			aggregatedDiscountInfoV3: {
				header: "ITEMS",
				subHeader: "AT ₹199",
			},
			differentiatedUi: {
				displayType: "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
				differentiatedUiMediaDetails: {
					mediaType: "ADS_MEDIA_ENUM_IMAGE",
					lottie: {},
					video: {},
				},
			},
			reviewsSummary: {},
			displayType: "RESTAURANT_DISPLAY_TYPE_DEFAULT",
			restaurantOfferPresentationInfo: {},
		},
		analytics: {},
		cta: {
			link: "https://www.swiggy.com/restaurants/chinese-wok-rahatan-pimple-saudagar-pune-688719",
			type: "WEBLINK",
		},
	},
	{
		info: {
			id: "765152",
			name: "Pizza Hut",
			cloudinaryImageId: "490629b70f89da8a5b93fc199ece335e",
			locality: "Pimpri chinchwad",
			areaName: "Punawale",
			costForTwo: "₹350 for two",
			cuisines: ["Pizzas"],
			avgRating: 4,
			parentId: "721",
			avgRatingString: "4.0",
			totalRatingsString: "500+",
			sla: {
				deliveryTime: 31,
				lastMileTravel: 3,
				serviceability: "SERVICEABLE",
				slaString: "30-35 mins",
				lastMileTravelString: "3.0 km",
				iconType: "ICON_TYPE_EMPTY",
			},
			availability: {
				nextCloseTime: "2024-05-26 05:00:00",
				opened: true,
			},
			badges: {
				imageBadges: [
					{
						imageId: "Rxawards/_CATEGORY-Pizza.png",
						description: "Delivery!",
					},
				],
			},
			isOpen: true,
			type: "F",
			badgesV2: {
				entityBadges: {
					imageBased: {
						badgeObject: [
							{
								attributes: {
									description: "Delivery!",
									imageId: "Rxawards/_CATEGORY-Pizza.png",
								},
							},
						],
					},
					textBased: {},
					textExtendedBadges: {},
				},
			},
			aggregatedDiscountInfoV3: {
				header: "50% OFF",
				subHeader: "UPTO ₹100",
			},
			differentiatedUi: {
				displayType: "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
				differentiatedUiMediaDetails: {
					mediaType: "ADS_MEDIA_ENUM_IMAGE",
					lottie: {},
					video: {},
				},
			},
			reviewsSummary: {},
			displayType: "RESTAURANT_DISPLAY_TYPE_DEFAULT",
			restaurantOfferPresentationInfo: {},
		},
		analytics: {},
		cta: {
			link: "https://www.swiggy.com/restaurants/pizza-hut-pimpri-chinchwad-punawale-pune-765152",
			type: "WEBLINK",
		},
	},
	{
		info: {
			id: "441447",
			name: "Burger King",
			cloudinaryImageId: "e33e1d3ba7d6b2bb0d45e1001b731fcf",
			locality: "Hinjewadi",
			areaName: "Hinjewadi",
			costForTwo: "₹350 for two",
			cuisines: ["Burgers", "American"],
			avgRating: 4.1,
			parentId: "166",
			avgRatingString: "4.1",
			totalRatingsString: "10K+",
			sla: {
				deliveryTime: 32,
				lastMileTravel: 4.3,
				serviceability: "SERVICEABLE",
				slaString: "30-35 mins",
				lastMileTravelString: "4.3 km",
				iconType: "ICON_TYPE_EMPTY",
			},
			availability: {
				nextCloseTime: "2024-05-26 03:40:00",
				opened: true,
			},
			badges: {
				imageBadges: [
					{
						imageId: "Rxawards/_CATEGORY-Burger.png",
						description: "Delivery!",
					},
				],
			},
			isOpen: true,
			type: "F",
			badgesV2: {
				entityBadges: {
					imageBased: {
						badgeObject: [
							{
								attributes: {
									description: "Delivery!",
									imageId: "Rxawards/_CATEGORY-Burger.png",
								},
							},
						],
					},
					textBased: {},
					textExtendedBadges: {},
				},
			},
			aggregatedDiscountInfoV3: {
				header: "50% OFF",
				subHeader: "UPTO ₹100",
			},
			differentiatedUi: {
				displayType: "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
				differentiatedUiMediaDetails: {
					mediaType: "ADS_MEDIA_ENUM_IMAGE",
					lottie: {},
					video: {},
				},
			},
			reviewsSummary: {},
			displayType: "RESTAURANT_DISPLAY_TYPE_DEFAULT",
			restaurantOfferPresentationInfo: {},
		},
		analytics: {},
		cta: {
			link: "https://www.swiggy.com/restaurants/burger-king-hinjewadi-pune-441447",
			type: "WEBLINK",
		},
	},
	{
		info: {
			id: "23716",
			name: "McDonald's",
			cloudinaryImageId: "RX_THUMBNAIL/IMAGES/VENDOR/2024/4/1/b5c7e325-a2b3-4334-b104-0b20df81dd93_23716.JPG",
			locality: "Marunji Road",
			areaName: "Hinjawadi",
			costForTwo: "₹400 for two",
			cuisines: ["Burgers", "Beverages", "Cafe", "Desserts"],
			avgRating: 4.4,
			parentId: "630",
			avgRatingString: "4.4",
			totalRatingsString: "10K+",
			sla: {
				deliveryTime: 36,
				lastMileTravel: 8.4,
				serviceability: "SERVICEABLE",
				slaString: "35-40 mins",
				lastMileTravelString: "8.4 km",
				iconType: "ICON_TYPE_EMPTY",
			},
			availability: {
				nextCloseTime: "2024-05-26 03:45:00",
				opened: true,
			},
			badges: {
				imageBadges: [
					{
						imageId: "Rxawards/_CATEGORY-Burger.png",
						description: "Delivery!",
					},
				],
			},
			isOpen: true,
			aggregatedDiscountInfoV2: {},
			type: "F",
			badgesV2: {
				entityBadges: {
					imageBased: {
						badgeObject: [
							{
								attributes: {
									description: "Delivery!",
									imageId: "Rxawards/_CATEGORY-Burger.png",
								},
							},
						],
					},
					textBased: {},
					textExtendedBadges: {},
				},
			},
			differentiatedUi: {
				displayType: "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
				differentiatedUiMediaDetails: {
					mediaType: "ADS_MEDIA_ENUM_IMAGE",
					lottie: {},
					video: {},
				},
			},
			reviewsSummary: {},
			displayType: "RESTAURANT_DISPLAY_TYPE_DEFAULT",
			restaurantOfferPresentationInfo: {},
		},
		analytics: {},
		cta: {
			link: "https://www.swiggy.com/restaurants/mcdonalds-marunji-road-hinjawadi-pune-23716",
			type: "WEBLINK",
		},
	},
	{
		info: {
			id: "260823",
			name: "La Pino'z Pizza",
			cloudinaryImageId: "hfwa38io1akqusshdyug",
			locality: "Wakad",
			areaName: "Wakad",
			costForTwo: "₹200 for two",
			cuisines: ["Pizzas", "Pastas", "Italian", "Desserts", "Beverages"],
			avgRating: 4,
			parentId: "4961",
			avgRatingString: "4.0",
			totalRatingsString: "1K+",
			sla: {
				deliveryTime: 28,
				lastMileTravel: 5.5,
				serviceability: "SERVICEABLE",
				slaString: "25-30 mins",
				lastMileTravelString: "5.5 km",
				iconType: "ICON_TYPE_EMPTY",
			},
			availability: {
				nextCloseTime: "2024-05-26 03:00:00",
				opened: true,
			},
			badges: {},
			isOpen: true,
			type: "F",
			badgesV2: {
				entityBadges: {
					imageBased: {},
					textBased: {},
					textExtendedBadges: {},
				},
			},
			aggregatedDiscountInfoV3: {
				header: "50% OFF",
				subHeader: "UPTO ₹100",
			},
			differentiatedUi: {
				displayType: "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
				differentiatedUiMediaDetails: {
					mediaType: "ADS_MEDIA_ENUM_IMAGE",
					lottie: {},
					video: {},
				},
			},
			reviewsSummary: {},
			displayType: "RESTAURANT_DISPLAY_TYPE_DEFAULT",
			restaurantOfferPresentationInfo: {},
		},
		analytics: {},
		cta: {
			link: "https://www.swiggy.com/restaurants/la-pinoz-pizza-wakad-pune-260823",
			type: "WEBLINK",
		},
	},
	{
		info: {
			id: "36014",
			name: "Subway",
			cloudinaryImageId: "63178e3e64d503a479f2a2048a474552",
			locality: "KAILASH HOTEL",
			areaName: "Tathawade",
			costForTwo: "₹350 for two",
			cuisines: ["Healthy Food", "Salads", "Snacks", "Desserts", "Beverages"],
			avgRating: 3.8,
			parentId: "2",
			avgRatingString: "3.8",
			totalRatingsString: "10K+",
			sla: {
				deliveryTime: 35,
				lastMileTravel: 4,
				serviceability: "SERVICEABLE",
				slaString: "30-35 mins",
				lastMileTravelString: "4.0 km",
				iconType: "ICON_TYPE_EMPTY",
			},
			availability: {
				nextCloseTime: "2024-05-26 02:59:00",
				opened: true,
			},
			badges: {},
			isOpen: true,
			type: "F",
			badgesV2: {
				entityBadges: {
					imageBased: {},
					textBased: {},
					textExtendedBadges: {},
				},
			},
			aggregatedDiscountInfoV3: {
				header: "₹150 OFF",
				subHeader: "ABOVE ₹299",
				discountTag: "FLAT DEAL",
			},
			differentiatedUi: {
				displayType: "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
				differentiatedUiMediaDetails: {
					mediaType: "ADS_MEDIA_ENUM_IMAGE",
					lottie: {},
					video: {},
				},
			},
			reviewsSummary: {},
			displayType: "RESTAURANT_DISPLAY_TYPE_DEFAULT",
			restaurantOfferPresentationInfo: {},
		},
		analytics: {},
		cta: {
			link: "https://www.swiggy.com/restaurants/subway-kailash-hotel-tathawade-pune-36014",
			type: "WEBLINK",
		},
	},
];