import React from 'react';
import App from '../App';

const Home = () => {
    return (
        <div>
            <App/>
        </div>
    );
}

export default Home;
