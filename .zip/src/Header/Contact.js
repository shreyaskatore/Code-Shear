import React from 'react';
import Header from './Header';

const Contact = () => {
    return (
		<div>
			<Header />
			<h2>Contact</h2>
		</div>
	);
}

export default Contact;
