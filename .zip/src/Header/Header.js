import React from "react";
import { useState } from "react";
import Home from "./Home";
import Aboutus from "./Aboutus";
import Contact from "./Contact";
import { Link } from "react-router-dom";
import "./Header.css";

const Header = () => {
	const [isLoggedIn, setIsLoggedIn] = useState(false);

	return (
		<div className="header">
			<img
				className="logo"
				alt="Logo"
				src="https://cdn.dribbble.com/users/2102703/screenshots/13943094/media/479965c0875a557a6d2564757bc9f20f.jpg"
			/>
			<ul>
				<li>
					<Link to="/"> 
					<Home />
					 </Link>
				</li>
				<li>
					<Link to="/aboutus">
					<Aboutus />
					</Link>
				</li>
				<li><Link to="/contact"><Contact /></Link></li>
				<li>Cart</li>
			</ul>
			<div>
				{isLoggedIn ? (
					<button onClick={() => setIsLoggedIn(false)}>Logout</button>
				) : (
					<button onClick={() => setIsLoggedIn(true)}>Login</button>
				)}
			</div>
		</div>
	);
};

export default Header;
