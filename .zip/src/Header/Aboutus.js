import React from 'react';
import Header from './Header';

const Aboutus = () => {
    return (
        <div>
            <Header/>
            <h2>About us</h2>
        </div>
    );
}

export default Aboutus;
