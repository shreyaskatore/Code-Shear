import Restrauntcard from "./Restrauntcard";
import ShimmerUI from "./ShimmerUI";
// import { restrauntList } from "../Constant";
import "./Body.css";
import { useState, useEffect } from "react";

const Body = () => {
	const [searchInput, setSearchInput] = useState("");
	const [restraunts, setRestraunts] = useState([]);
	const [filteredRestraunts, setFilteredRestraunts] = useState([])

	const searchFunction = (searchInput) => {
		const filterdata = restraunts.filter((restraunts) =>
			restraunts?.info?.name.toLowerCase().includes(searchInput.toLowerCase())
		);
		return filterdata;
	};

	useEffect(() => {
		async function getRestrauntData() {
			const data = await fetch(
				"https://www.swiggy.com/dapi/restaurants/list/v5?lat=18.61610&lng=73.72860&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"
			);
			const json = await data.json();
			console.log(json?.data?.cards[1]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
			setRestraunts(json?.data?.cards[1]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
			setFilteredRestraunts(json?.data?.cards[1]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
		}
		getRestrauntData();
	}, []);
	if(!restraunts) return null;
	

	return restraunts.length === 0 ? (
		<ShimmerUI />
	) : (
		<>
			<div className="search-container">
				<input
					type="text"
					className="search-input"
					placeholder="Search"
					Value={searchInput}
					onChange={(e) => {
						setSearchInput(e.target.value);
						const data = searchFunction(e.target.value);
						setFilteredRestraunts(data);
					}}
				/>
				<button
					className="search-btn"
					onClick={() => {
						const data = searchFunction(searchInput);
						setFilteredRestraunts(data);
					}}
				>
					Search
				</button>
			</div>
			<div className="body">
					{filteredRestraunts.map((restraunt, index) =>
						restraunt.info ? <Restrauntcard {...restraunt} key={restraunts[index].info.id} /> : null
					)}
			</div>
		</>
	);
};

export default Body;
