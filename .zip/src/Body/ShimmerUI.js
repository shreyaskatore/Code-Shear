import React from 'react';

const ShimmerUI = () => {
    return (
        <div>
            <h3>Shimmer is loading........</h3>
        </div>
    );
}

export default ShimmerUI;
