import React from "react";
import {Cardimg} from '../Constant';
import "./Restrauntcard.css";

const Restrauntcard = ({ ...restraunt }) => {
	return (
		<div className="card">
			<img alt="Res img" src={Cardimg + restraunt.info?.cloudinaryImageId} />
			<h4>{restraunt.info?.name}</h4>
			<h5>{restraunt.info?.avgRating} stars</h5>
			<h6>{restraunt.info?.cuisines.join(", ")}</h6>
		</div>
	);
};

export default Restrauntcard;
